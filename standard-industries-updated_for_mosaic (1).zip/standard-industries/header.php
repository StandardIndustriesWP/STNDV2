<?php

$GLOBALS['timberContext'] = Timber::get_context();

ob_start();
